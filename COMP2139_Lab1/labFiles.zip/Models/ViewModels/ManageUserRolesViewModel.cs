﻿namespace COMP2139_Lab1.Models.ViewModels
{
    public class ManageUserRolesViewModel
    {
        public string RoleID { get; set; }
        public string RoleName { get; set; }

        public bool Selected { get; set; }
    }
}
