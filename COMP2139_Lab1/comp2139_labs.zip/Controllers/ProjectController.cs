﻿using COMP2139_Lab1.Models;
using Microsoft.AspNetCore.Mvc;

namespace COMP2139_Lab1.Controllers
{
    public class ProjectController : Controller
    {
        public IActionResult Index()
        {
            var projects = new List<Project>()
            {
                new Project {projectID = 1, Name = "Project 1", Description = "My First Project"}
            };

            return View(projects);
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Details()
        {
            return View();
        }
    }
}
