﻿namespace COMP2139_Lab1.Enum
{
    public enum Roles
    {
        SuperAdmin,
        Admin,
        Moderator,
        Basic
    }
}
